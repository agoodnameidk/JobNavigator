package com.example.JobNavigator;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.Locale;

public class JobActivity extends AppCompatActivity implements View.OnClickListener {

    FloatingActionButton fabLike;
    boolean liked;
    TextToSpeech tts;
    String jobID;
    ImageView imageView;
    DatabaseReference jobRef;
    TextView tvTitle, tvDescription, tvImageUrl, tvRequirements, tvInstructions, tvEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        liked = false;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_card);
        jobID = getIntent().getStringExtra("jobID");
        fabLike = findViewById(R.id.fabLike);
        tvTitle = findViewById(R.id.tvTitle);
        tvDescription = findViewById(R.id.tvDescription);
        tvRequirements = findViewById(R.id.tvRequirements);
        tvInstructions = findViewById(R.id.tvInstructions);
        tvEmail = findViewById(R.id.tvEmail);
        imageView = findViewById(R.id.imageID);
        fabLike.setOnClickListener(this);

        // Initialize the TextToSpeech object
        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    tts.setLanguage(Locale.ENGLISH);
                }
            }
        });
        jobRef = FirebaseDatabase.getInstance().getReference("jobs").child(jobID);
        jobRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Set the job's values in the activity
                if (dataSnapshot.exists()) {
                    Job job = dataSnapshot.getValue(Job.class);

                    if (job != null) {
                        String title = job.getTitle();
                        String description = job.getDescription();
                        String imageUrl = job.getImageUrl();
                        String requirements = job.getRequirements();
                        String instructions = job.getInstructions();
                        String email = job.getEmail();

                        tvTitle.setText(title);
                        tvDescription.setText(description);
                        tvRequirements.setText(requirements);
                        Picasso.get().load(imageUrl).into(imageView);
                        tvInstructions.setText(instructions);
                        tvEmail.setText(email);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle the error if needed
            }
        });
    }

    public void onClick(View view) {
        if (view.getId() == R.id.fabLike) {
            //likes job or removes like from job
            if (liked == false)
                fabLike.setImageResource(R.drawable.heart);
            else
                fabLike.setImageResource(R.drawable.favorite);
            liked = !liked;
        }
        //adds Requirements or Instructions
        if (view.getId() == R.id.fabTTSRequirements)
            tts.speak(tvRequirements.getText().toString(),TextToSpeech.QUEUE_FLUSH,null, null);
        if (view.getId() == R.id.fabTTSInstructions)
            tts.speak(tvInstructions.getText().toString(),TextToSpeech.QUEUE_FLUSH,null, null);
        if (view.getId() == R.id.tvEmail)
        {
            Intent intent = new Intent(getApplicationContext(), otherPersona.class);
            intent.putExtra("email", tvEmail.getText());
            startActivity(intent);
        }
        if(view.getId() == R.id.fabDelete)
        {
            //builds an alert Dialog to ask if the user is sure to delete job from server
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setIcon(this.getDrawable(R.drawable.baseline_delete_24));
            builder.setTitle("Delete Job");
            builder.setMessage("Are you sure you want to delete this job?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Toast.makeText(getApplicationContext(),"Job Deleted Successfully!",Toast.LENGTH_LONG).show();
                            FirebaseDatabase.getInstance().getReference("jobs").child(jobID).removeValue();
                            Intent intent = new Intent(getApplicationContext(), Menu.class);
                            startActivity(intent);
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            AlertDialog dialog = builder.create();
            dialog.show();

        }
    }
}