package com.example.JobNavigator;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.Random;


public class BackgroundMusicService extends Service {
    MediaPlayer mediaPlayer;
    boolean is = false;

    @Override
    public void onCreate() {
        final int min = 1;
        final int max = 3;
        //choose random song from 'playlist' found in raw folder
        final int random = new Random().nextInt((max - min) + 1) + min;
        if(random == 1)
            mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.song_1);
        else if(random == 2)
            mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.song_2);
        else if(random == 3)
            mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.song_3);
        Toast.makeText(this, "Track " + random + " Playing" , Toast.LENGTH_SHORT).show();
        mediaPlayer.setLooping(true);
        mediaPlayer.start();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    public void onStart(Intent intent, int flags, int startId) {
    }

    @Override
    public void onDestroy() {
        mediaPlayer.stop();
        mediaPlayer.release();
        mediaPlayer = null;
    }
}