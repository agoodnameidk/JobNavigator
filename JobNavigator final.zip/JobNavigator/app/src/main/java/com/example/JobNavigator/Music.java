package com.example.JobNavigator;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.concurrent.TimeUnit;

public class Music extends Fragment implements View.OnClickListener {


    private Intent musicServiceIntent, musicIntent;
    private Button btnStart, btnStop;
    private CountDownTimer ctd;
    private TextView timer;
    int i = 0;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_music, container, false);
        btnStart = view.findViewById(R.id.beginMusic);
        btnStop = view.findViewById(R.id.stopMusic);
        timer = view.findViewById(R.id.timer);
        btnStart.setOnClickListener(this);
        btnStop.setOnClickListener(this);
        //calls BackgroundMusicService to hear music as a service
        musicServiceIntent = new Intent(getActivity().getApplicationContext(), BackgroundMusicService.class);
        return view;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.beginMusic:
                //sends signal to BackgroundMusicService to make it play music
                ImageView image1 = (ImageView) getView().findViewById(R.id.record);
                v.getContext().startService(new Intent(getActivity().getApplicationContext(), BackgroundMusicService.class));
                image1.startAnimation(
                        AnimationUtils.loadAnimation(getActivity(), R.anim.anim1) );
                //starts CountDownTimer with a preset of 5 minutes as a healthy relaxing break
                i = 0;
                ctd = new CountDownTimer(300000, 1000) {
                    @Override
                    public void onTick(long l) {
                        timer.setText(String.format("Break Reminder: %02d min: %02d sec",
                                TimeUnit.MILLISECONDS.toMinutes(l) % 60,
                                TimeUnit.MILLISECONDS.toSeconds(l) % 60));
                        i++;
                    }

                    @Override
                    public void onFinish() {
                        timer.setText("Break has Ended, you may go back to work");
                    }
                }.start();
                break;
            case R.id.stopMusic:
                //sends signal to BackgroundMusicService to make it stop playing music
                v.getContext().stopService(new Intent(getActivity().getApplicationContext(), BackgroundMusicService.class));
                ImageView image = (ImageView) getView().findViewById(R.id.record);
                image.clearAnimation();
                ctd.cancel();
                timer.setText("Happy working!");
                break;
        }
    }
}