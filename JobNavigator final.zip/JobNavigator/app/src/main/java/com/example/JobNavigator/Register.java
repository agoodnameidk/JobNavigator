package com.example.JobNavigator;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity implements View.OnClickListener {



    EditText usernameEdt, emailEdt, phoneEdt, passwordEdt, repeatEdt;
    Button buttonSend;

    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        TextView btnHaveAccount;
        btnHaveAccount = (findViewById(R.id.btnHaveAccount));
        try {
            this.getSupportActionBar().hide();
        }
        catch (NullPointerException e) {
        }

        // initializing all our variables.
        usernameEdt = findViewById(R.id.Username);
        emailEdt = findViewById(R.id.Email);
        phoneEdt = findViewById(R.id.Phone);
        passwordEdt = findViewById(R.id.Password);
        repeatEdt = findViewById(R.id.RepeatPassword);
        buttonSend = findViewById(R.id.buttonSend);
        mAuth = FirebaseAuth.getInstance();

    }

    @Override
    public void onClick(View view) {
        //moves user to login page
        if (view.getId() == R.id.btnHaveAccount){
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    // Start the next activity here
                    Intent intent = new Intent(Register.this, Login.class);
                    startActivity(intent);
                    finish();
                }
            }, 0);
        }
        else if(view.getId() == R.id.buttonSend){
            createUser();
        }
    }
    private void createUser(){
        String email = emailEdt.getText().toString();
        String password = passwordEdt.getText().toString();
        String username = usernameEdt.getText().toString();
        String phone = phoneEdt.getText().toString();
        String repeat = repeatEdt.getText().toString();

        //checks all registration values
        if (TextUtils.isEmpty(email)){
            emailEdt.setError("Email cannot be empty");
            emailEdt.requestFocus();
        }else if (TextUtils.isEmpty(password)){
            passwordEdt.setError("Password cannot be empty");
            passwordEdt.requestFocus();
        }else if (TextUtils.isEmpty(username)){
            usernameEdt.setError("Username cannot be empty");
            usernameEdt.requestFocus();
        }else if (TextUtils.isEmpty(phone)){
            phoneEdt.setError("Phone cannot be empty");
            phoneEdt.requestFocus();
        }else if (phone.length() != 9){
            phoneEdt.setError("Phone must be 9 digits long");
            phoneEdt.requestFocus();
        }else if (!repeat.equals(password)){
            repeatEdt.setError("Password needs to be matching");
            repeatEdt.requestFocus();
        }else{
            //sends user data to Firebase authentication database
            mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete( Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        //sends user to login, which will immediately check if user is alraedy registered, and will divert user to the main page
                        Toast.makeText(Register.this, "User registered successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Register.this, Login.class));
                    }else{
                        //sends server error message as toast
                        Toast.makeText(Register.this, "Registration Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}