package com.example.JobNavigator;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class JobAdapter extends RecyclerView.Adapter<JobViewHolder> {

    private Context context;
    private List<Job> jobList;

    public JobAdapter(Context context, List<Job> jobList) {
        this.context = context;
        this.jobList = jobList;
    }
    public JobAdapter(List<Job> jobList) {
        this.jobList = jobList;
    }
    //adapts Job data to preview on recyclerView

    @Override
    public JobViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflates cardView in the RecyclerView
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.job_card, parent, false);
        return new JobViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(JobViewHolder holder, int position) {
        //gets specific job's values based on position
        Job job = jobList.get(position);
        holder.jobTextView.setText(job.getTitle());
        holder.jobLikesView.setText(job.getLikeCount());
        Glide.with(holder.itemView)
                .load(job.getImageUrl()).dontAnimate().into(holder.jobImageView);
    }

    @Override
    //returns number of all jobs in database
    public int getItemCount() {
        return jobList.size();
    }
}