package com.example.JobNavigator;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.UUID;

public class createNewJob extends AppCompatActivity implements View.OnClickListener {

    TextView tvRequirements, tvInstructions;
    private FirebaseStorage storage;
    private StorageReference storageRef;
    EditText etTitle, etDescription, etRequirement, etInstruction;
    AppCompatButton btnAddRequirement, btnAddInstruction;
    FloatingActionButton btnPublish;
    ImageButton imgJob;
    private String email;
    ActivityResultLauncher<Intent> arlMakePhoto;
    private FirebaseUser currentUser;
    int InstructionCount = 1;
    int requirementCount = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //creates all variables, and connects to firebase authentication, firebase database and firebase storage
        setContentView(R.layout.activity_create_new_job);
        etTitle = findViewById(R.id.etTitle);
        btnAddRequirement = new AppCompatButton(this);
        etDescription = findViewById(R.id.etDescription);
        etRequirement = findViewById(R.id.etRequirement);
        btnAddRequirement = findViewById(R.id.btnAddRequirement);
        tvRequirements = findViewById(R.id.tvRequirements);
        tvInstructions = findViewById(R.id.tvInstructions);
        etInstruction = findViewById(R.id.etInstructions);
        btnAddInstruction = findViewById(R.id.btnAddInstructions);
        storage = FirebaseStorage.getInstance();
        storageRef = storage.getReference("jobs");
        imgJob = findViewById(R.id.imgJob);
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        currentUser = firebaseAuth.getCurrentUser();
        btnPublish = findViewById(R.id.btnPublish);
        btnPublish.setOnClickListener(this);
        FirebaseApp.initializeApp(this);
        initElements();

        //asks permission for camera
        if(ContextCompat.checkSelfPermission(createNewJob.this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(createNewJob.this, new String[]{Manifest.permission.CAMERA},100);
        }
    }
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(createNewJob.this, Menu.class);
        startActivity(intent);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnAddRequirement)
        {
            //adds requirements to the textview as a numbered list
            if(!etRequirement.getText().toString().matches(""))
            {
                String tmp = etRequirement.getText().toString();
                String prev = tvRequirements.getText().toString();
                tvRequirements.setText(prev + requirementCount + ". " + tmp + "\n" + "\n");
                requirementCount++;
            }
            else
                Toast.makeText(this, "Please enter requirements", Toast.LENGTH_SHORT).show();

        }
        if (view.getId() == R.id.btnAddInstructions)
        {
            //adds Instructions to the textview as a numbered list
            if(!etInstruction.getText().toString().matches("")) {
                String tmp = etInstruction.getText().toString();
                String prev = tvInstructions.getText().toString();
                tvInstructions.setText(prev + InstructionCount + ". " + tmp + "\n" + "\n");
                InstructionCount++;
            }
            else
                Toast.makeText(this, "Please enter an instruction", Toast.LENGTH_SHORT).show();
        }
        if(view.getId() == R.id.imgJob){
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            arlMakePhoto.launch(intent);
            //opens camera
        }

        if (view.getId() == R.id.btnPublish){
            uploadJobToFirebase();
        }
    }
    private void initElements() {
        arlMakePhoto=registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            Bundle bundle = result.getData().getExtras();
                            Bitmap bitmap = (Bitmap) bundle.get("data");
                            imgJob.setImageBitmap(bitmap);
                        }
                    }
                }
        );
    }

    private void uploadJobToFirebase() {
        //uploads created job to firebase's realtime database
        String title = etTitle.getText().toString();
        String description = etDescription.getText().toString();
        String requirements = tvRequirements.getText().toString();
        String instructions = tvInstructions.getText().toString();

        Bitmap jobImage = ((BitmapDrawable) imgJob.getDrawable()).getBitmap();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        jobImage.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageData = baos.toByteArray();
        String jobKey = UUID.randomUUID().toString();
        DatabaseReference jobDatabaseRef = FirebaseDatabase.getInstance().getReference("jobs").child(jobKey);
        StorageReference imageRef = storageRef.child("job_images/" + UUID.randomUUID().toString() + ".jpg");
        UploadTask uploadTask = imageRef.putBytes(imageData);
        //get user's email
        email = currentUser.getEmail();

        uploadTask.continueWithTask(task -> {
            if (!task.isSuccessful()) {
                throw task.getException();
            }
            return imageRef.getDownloadUrl();
        }).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                //if job was successfully uploaded set a database reference to finalize job creation
                Uri downloadUri = task.getResult();
                String imageUrl = downloadUri.toString();

                Job job = new Job(jobKey, title, description, requirements, instructions, imageUrl, email);
                jobDatabaseRef.setValue(job);
                startActivity(new Intent(createNewJob.this, Menu.class));
                Toast.makeText(createNewJob.this, "Job Published", Toast.LENGTH_SHORT).show();
            } else {
                Exception exception = task.getException();
            }
        });
    }

}