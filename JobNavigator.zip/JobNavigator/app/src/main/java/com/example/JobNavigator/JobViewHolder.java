package com.example.JobNavigator;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class JobViewHolder extends RecyclerView.ViewHolder {

    public CardView cardView;
    TextView jobTextView;
    ImageView jobImageView;
    TextView jobLikesView;

    public JobViewHolder(View itemView) {
        super(itemView);
        cardView = itemView.findViewById(R.id.card_view);
        jobTextView = itemView.findViewById(R.id.jobC_name);
        jobImageView = itemView.findViewById(R.id.jobC_image);
        jobLikesView = itemView.findViewById(R.id.jobC_likes);
    }
}