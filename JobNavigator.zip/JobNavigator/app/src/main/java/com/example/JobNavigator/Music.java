package com.example.JobNavigator;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

public class Music extends Fragment implements View.OnClickListener {


    private Intent musicServiceIntent, musicIntent;
    private Button btnStart, btnStop;
    private int until = 1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_music, container, false);
        btnStart = view.findViewById(R.id.beginMusic);
        btnStop = view.findViewById(R.id.stopMusic);
        btnStart.setOnClickListener(this);
        btnStop.setOnClickListener(this);
        musicServiceIntent = new Intent(getActivity().getApplicationContext(), BackgroundMusicService.class);
        return view;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.beginMusic:
                ImageView image1 = (ImageView) getView().findViewById(R.id.record);
                v.getContext().startService(new Intent(getActivity().getApplicationContext(), BackgroundMusicService.class));
                image1.startAnimation(
                        AnimationUtils.loadAnimation(getActivity(), R.anim.anim1) );

                break;
            case R.id.stopMusic:
                v.getContext().stopService(new Intent(getActivity().getApplicationContext(), BackgroundMusicService.class));
                ImageView image = (ImageView) getView().findViewById(R.id.record);
                image.clearAnimation();
                break;
        }
    }
}