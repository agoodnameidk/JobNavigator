package com.example.JobNavigator;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import de.hdodenhof.circleimageview.CircleImageView;
public class Persona extends Fragment implements View.OnClickListener {

    CircleImageView imgProfile;
    FloatingActionButton btnAddPhoto;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private TextView tvEmail;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_persona, container, false);
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA}, 100);

        }
        mAuth = FirebaseAuth.getInstance();
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        currentUser = firebaseAuth.getCurrentUser();
        imgProfile = view.findViewById(R.id.circleImageView);
        btnAddPhoto = view.findViewById(R.id.btnAddPhoto);
        tvEmail = view.findViewById(R.id.textView2);
        btnAddPhoto.setOnClickListener(this);
        tvEmail.setText(currentUser.getEmail());
        return view;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 100){
            Bitmap bitmap  = (Bitmap) data.getExtras().get("data");
            imgProfile.setImageBitmap(bitmap);
        }
        else if (requestCode == 100 && resultCode == getActivity().RESULT_CANCELED) {
            getActivity().getSupportFragmentManager().popBackStack();
        }

    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); {
            startActivityForResult(intent, 100);
        }
    }
}