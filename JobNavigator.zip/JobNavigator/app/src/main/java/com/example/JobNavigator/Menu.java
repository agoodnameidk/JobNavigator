package com.example.JobNavigator;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Menu extends AppCompatActivity implements View.OnClickListener {

    BottomNavigationView bottomNavigationView;
    JobsMain homeFragment = new JobsMain();
    Calendar calendarFragment = new  Calendar();
    Persona profileFragment = new Persona();

    Music musicFragment = new Music();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
            this.getSupportActionBar().hide();
        CoordinatorLayout coordinatorLayout = findViewById(R.id.coordinator_layout);
        coordinatorLayout.setBackgroundColor(Color.WHITE);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragContainer, homeFragment).commit();
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener(){
            @SuppressLint("NonConstantResourceId")
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menuJob:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragContainer, homeFragment).commit();
                        return true;
                    case R.id.menuCalendar:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragContainer, calendarFragment).commit();
                        return true;
                    case R.id.menuMusic:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragContainer, musicFragment).commit();
                        return true;
                    case R.id.menuPersona:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragContainer, profileFragment).commit();
                        return true;
                }
                return false;
            }
        });
    }
    //sends user to createnewjob

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.fab){
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    // Start the next activity here
                    Intent intent = new Intent(Menu.this, createNewJob.class);
                    startActivity(intent);
                    finish();
                }
            }, 0);
        }
    }
}