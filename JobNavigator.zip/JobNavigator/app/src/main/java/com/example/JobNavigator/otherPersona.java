package com.example.JobNavigator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class otherPersona extends AppCompatActivity {
    private List<Job> jobList;
    String likeCount;
    private JobAdapter jobAdapter;
    private String UserEmail;
    private TextView emailTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_persona);
        RecyclerView recyclerView = findViewById(R.id.jobRecycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        jobList = new ArrayList<>();
        jobAdapter = new JobAdapter(jobList);
        recyclerView.setAdapter(jobAdapter);
        UserEmail = getIntent().getStringExtra("email");
        emailTV = findViewById(R.id.textView2);
        emailTV.setText(UserEmail);
        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(this, recyclerView ,new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position) {
                        Intent intent = new Intent(getApplicationContext(), JobActivity.class);
                        startActivity(intent);
                    }
                    @Override public void onLongItemClick(View view, int position) {}
                })
        );

        fetchJobFromFirebase();
    }

    private void fetchJobFromFirebase() {
        DatabaseReference jobRef = FirebaseDatabase.getInstance().getReference("jobs");

        Query query = jobRef.orderByChild("email").equalTo(UserEmail);

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                jobList.clear();
                for (DataSnapshot jobSnapshot : dataSnapshot.getChildren()) {
                    Job job = jobSnapshot.getValue(Job.class);
                    if (job != null) {
                        jobList.add(job);
                    }
                }
                jobAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(otherPersona.this, "Failed to fetch jobs", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
