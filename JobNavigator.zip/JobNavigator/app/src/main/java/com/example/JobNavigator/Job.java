package com.example.JobNavigator;

public class Job {
    private String jobID;
    private String title;
    private String imageUrl;
    private String description;
    private String requirements;
    private String instructions;
    private String likeCount;
    private String money;
    private String email;

    public Job(String jobID, String title, String imageUrl, String description, String requirements, String instructions, String money, String likeCount) {
        this.jobID = jobID;
        this.title = title;
        this.imageUrl = imageUrl;
        this.description = description;
        this.requirements = requirements;
        this.instructions = instructions;
        this.money = money;
        this.likeCount = likeCount;
    }
    public Job(String title, String imageUrl, String likeCount) {
        this.title = title;
        this.imageUrl = imageUrl;
        this.likeCount = likeCount;
    }

    public Job() {

    }

    public Job(String jobID, String title, String description, String requirements, String instructions, String imageUrl, String email) {
        this.jobID = jobID;
        this.title = title;
        this.description = description;
        this.requirements = requirements;
        this.instructions = instructions;
        this.imageUrl = imageUrl;
        this.email = email;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRequirements() {
        return requirements;
    }

    public void setRequirements(String requirements) {
        this.requirements = requirements;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public String getMoney() { return money; }

    public void setMoney(String money) { this.money = money;}
    public String getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(String likeCount) { this.likeCount = likeCount; }



    public String getEmail() {
        return email;
    }

    public String getJobID() {
        return jobID;
    }
}
